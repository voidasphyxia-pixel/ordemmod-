#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <polytone:gpu_particle.glsl>

in vec3 Position;
in vec3 Velocity;
in vec2 SpawnLife;
in vec4 Params;
in vec4 Color;
in ivec2 UV2;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;

const float PI = 3.14159265359;
const float TAU = 6.28318530718;

void hideParticle() {
    gl_Position = vec4(-2.0, -2.0, -2.0, 1.0);
    sphericalVertexDistance = 0.0;
    cylindricalVertexDistance = 0.0;
    texCoord0 = vec2(0.0);
    vertexColor = vec4(0.0);
}

bool getSurfaceRelativeY(
    vec2 relativeXZ,
    out float surfaceRelativeY
) {
    vec2 uv =
        (relativeXZ - HeightmapInfo.xy) /
        HeightmapInfo.z;

    if (
        any(lessThan(uv, vec2(0.0))) ||
        any(greaterThanEqual(uv, vec2(1.0)))
    ) {
        return false;
    }

    ivec2 texelPosition =
        ivec2(uv * HeightmapInfo.z);

    vec4 heightData = texelFetch(
        Sampler1,
        texelPosition,
        0
    );

    float surfaceWorldY =
        HeightmapInfo.w +
        heightData.r * 255.0 +
        heightData.g * 255.0 * 256.0;

    surfaceRelativeY =
        surfaceWorldY - CameraY;

    return true;
}

void main() {
    int corner = gl_VertexID & 3;

    float life = SpawnLife.y;
    float age = Time - SpawnLife.x;

    if (life <= 0.0 || age < 0.0 || age >= life) {
        hideParticle();
        return;
    }

    float lifetimeProgress = age / life;
    float phase = Params.z * TAU;

    /*
     * Плавное вертикальное движение:
     * dy = sin(AGE * 0.04 + CUSTOM * 2*pi) * 0.01
     */
    float verticalOffset =
        (
            cos(phase) -
            cos(age * 0.04 + phase)
        ) * 0.25;

    const float HEIGHT_ABOVE_SURFACE = 3.0;

    /*
    * Максимально допустимое возвышение поверхности
    * относительно высоты, на которой частица появилась.
    */
    const float MAX_SURFACE_RISE = 4.0;

    vec3 particlePos =
        Position +
        Origin;

    /*
    * Эмиттер находится на высоте игрока.
    * Сохраняем её до привязки частицы к heightmap.
    */
    float emitterRelativeY =
        particlePos.y;

    float surfaceRelativeY;

    if (
        !getSurfaceRelativeY(
            particlePos.xz,
            surfaceRelativeY
        )
    ) {
        hideParticle();
        return;
    }

    /*
    * Не отображаем частицы на деревьях, крышах
    * и других слишком высоких поверхностях.
    */
    if (
        surfaceRelativeY >
        emitterRelativeY + MAX_SURFACE_RISE
    ) {
        hideParticle();
        return;
    }

    particlePos.y =
        surfaceRelativeY +
        HEIGHT_ABOVE_SURFACE +
        verticalOffset;

    float distanceSquared =
        dot(particlePos, particlePos);

    /*
     * Скрываем частицу дальше 30 блоков.
     */
    if (distanceSquared > 900.0) {
        hideParticle();
        return;
    }

    float distanceToCamera =
        sqrt(distanceSquared);

    /*
     * Появление после 5 блоков.
     */
    float innerDistanceFade = clamp(
        (distanceSquared - 25.0) / 100.0,
        0.0,
        1.0
    );

    /*
     * Исчезновение между 20 и 25 блоками.
     */
    float outerDistanceFade = clamp(
        (25.0 - distanceToCamera) / 5.0,
        0.0,
        1.0
    );

    /*
     * Появление и исчезновение по lifetime.
     */
    float lifetimeFade = max(
        sin(PI * lifetimeProgress),
        0.0
    );

    float finalAlpha =
        Color.a *
        lifetimeFade *
        innerDistanceFade *
        outerDistanceFade;

    /*
     * Camera-facing billboard.
     */
    vec3 right = vec3(
        ModelViewMat[0][0],
        ModelViewMat[1][0],
        ModelViewMat[2][0]
    );

    vec3 up = vec3(
        ModelViewMat[0][1],
        ModelViewMat[1][1],
        ModelViewMat[2][1]
    );

    vec2 cornerPosition = vec2(
        corner == 1 || corner == 2
            ? 1.0
            : -1.0,

        corner >= 2
            ? 1.0
            : -1.0
    );

    /*
     * Начальный случайный roll и его плавное колебание.
     */
    float roll =
        phase +
        sin(age * 0.025 + phase) * 0.25;

    float rollSin = sin(roll);
    float rollCos = cos(roll);

    cornerPosition = vec2(
        cornerPosition.x * rollCos -
        cornerPosition.y * rollSin,

        cornerPosition.x * rollSin +
        cornerPosition.y * rollCos
    );

    float size = Params.x;

    vec3 renderPosition =
        particlePos +
        right * (cornerPosition.x * size) +
        up * (cornerPosition.y * size * Aspect);

    float u =
        corner == 1 || corner == 2
            ? 1.0
            : 0.0;

    float v =
        corner >= 2
            ? 0.0
            : 1.0;

    texCoord0 = vec2(u, v);

    vec4 lightColor = texelFetch(
        Sampler2,
        UV2 / 16,
        0
    );

    vertexColor =
        vec4(Color.rgb, finalAlpha) *
        lightColor;

    sphericalVertexDistance =
        fog_spherical_distance(renderPosition);

    cylindricalVertexDistance =
        fog_cylindrical_distance(renderPosition);

    gl_Position =
        ProjMat *
        ModelViewMat *
        vec4(renderPosition, 1.0);
}