#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <polytone:gpu_particle.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

const float FOG_WHITE_MIX = 0.25;

void main() {
    vec4 textureColor =
        texture(Sampler0, texCoord0);

    vec4 particleFogColor = vec4(
        mix(
            FogColor.rgb,
            vec3(1.0),
            FOG_WHITE_MIX
        ),
        FogColor.a
    );

    /*
     * Текстура используется как alpha-маска.
     * Цвет всегда берётся из осветлённого FogColor.
     */
    vec4 color = vec4(
        particleFogColor.rgb,
        textureColor.a *
        vertexColor.a *
        ColorModulator.a
    );

    if (color.a < AlphaCutoff) {
        discard;
    }

    fragColor = apply_fog(
        color,
        sphericalVertexDistance,
        cylindricalVertexDistance,
        FogEnvironmentalStart,
        FogEnvironmentalEnd,
        FogRenderDistanceStart,
        FogRenderDistanceEnd,
        particleFogColor
    );
}