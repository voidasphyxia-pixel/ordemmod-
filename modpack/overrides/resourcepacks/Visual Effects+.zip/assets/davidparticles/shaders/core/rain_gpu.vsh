#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <polytone:gpu_particle.glsl>

in vec3 Position;
in vec3 Velocity;
in vec2 SpawnLife;
in vec4 Params;
in vec4 Color;
in ivec2 UV2;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(std140) uniform RainStrength {
    float rainStrengthValue;
};

layout(std140) uniform PlayerRelativeX {
    float playerRelativeXValue;
};

layout(std140) uniform PlayerRelativeZ {
    float playerRelativeZValue;
};

const float SPEED_MULTIPLIER = 2.0;
const int COLLISION_STEPS = 8;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;

float hash(float seed, float salt) {
    return fract(
        sin(seed * 127.1 + salt * 311.7) *
        43758.5453
    );
}

vec3 rotateX(vec3 p, float angle) {
    float s = sin(angle);
    float c = cos(angle);

    return vec3(
        p.x,
        p.y * c - p.z * s,
        p.y * s + p.z * c
    );
}

vec3 rotateY(vec3 p, float angle) {
    float s = sin(angle);
    float c = cos(angle);

    return vec3(
        p.x * c + p.z * s,
        p.y,
        -p.x * s + p.z * c
    );
}

vec3 rotateZ(vec3 p, float angle) {
    float s = sin(angle);
    float c = cos(angle);

    return vec3(
        p.x * c - p.y * s,
        p.x * s + p.y * c,
        p.z
    );
}

void hideParticle() {
    gl_Position = vec4(-2.0, -2.0, -2.0, 1.0);
    sphericalVertexDistance = 0.0;
    cylindricalVertexDistance = 0.0;
    texCoord0 = vec2(0.0);
    vertexColor = vec4(0.0);
}

/*
 * Проверяет, находится ли точка ниже верхней
 * motion-blocking поверхности мира.
 */
bool isBelowSurface(vec3 position) {
    vec2 uv =
        (position.xz - HeightmapInfo.xy) /
        HeightmapInfo.z;

    /*
     * Точка находится за пределами доступной heightmap.
     * В таком случае не считаем её столкнувшейся.
     */
    if (
        any(lessThan(uv, vec2(0.0))) ||
        any(greaterThanEqual(uv, vec2(1.0)))
    ) {
        return false;
    }

    vec4 heightData = texelFetch(
        Sampler1,
        ivec2(uv * HeightmapInfo.z),
        0
    );

    float surfaceHeight =
        HeightmapInfo.w +
        heightData.r * 255.0 +
        heightData.g * 255.0 * 256.0;

    float particleWorldY =
        position.y + CameraY;

    return particleWorldY <= surfaceHeight;
}

/*
 * Проверяет весь путь частицы от начальной позиции
 * до текущей. Благодаря этому частица не должна
 * снова появляться после прохождения сквозь стену.
 */
bool pathHitsSurface(
    vec3 startPosition,
    vec3 currentPosition
) {
    for (int i = 0; i <= COLLISION_STEPS; i++) {
        float pathProgress =
            float(i) / float(COLLISION_STEPS);

        vec3 samplePosition = mix(
            startPosition,
            currentPosition,
            pathProgress
        );

        if (isBelowSurface(samplePosition)) {
            return true;
        }
    }

    return false;
}

void main() {
    int corner = gl_VertexID & 3;

    float life = SpawnLife.y;
    float age = Time - SpawnLife.x;

    if (life <= 0.0 || age < 0.0 || age >= life) {
        hideParticle();
        return;
    }

    float progress = age / life;
    float randomValue = Params.z;
    float seed = Params.w;

    /*
     * Кастомное движение.
     */
    vec3 movement = vec3(
        rainStrengthValue * 0.5,
        -0.75,
        randomValue * 0.08 - 0.04
    ) * SPEED_MULTIPLIER;

    /*
     * Центрируем горизонтальный путь относительно
     * исходной позиции частицы.
     */
    vec3 horizontalCentering = vec3(
        movement.x,
        0.0,
        movement.z
    ) * (life * 0.5);

    /*
     * Позиция, с которой визуально начинает движение
     * отцентрированная частица.
     */
    vec3 startPosition =
        Position -
        horizontalCentering +
        Origin;

    vec3 particlePos =
        startPosition +
        movement * age;

    /*
     * Heightmap collision.
     */
    if (
        KillBelowHeightmap == 1 &&
        pathHitsSurface(startPosition, particlePos)
    ) {
        hideParticle();
        return;
    }

    /*
     * Кастомное вращение.
     */
    float sideMultiplier =
        particlePos.x > playerRelativeXValue
        ? -1.0
        : 1.0;

    float xRotation =
        (
            particlePos.z < playerRelativeZValue
            ? -0.45
            : 0.45
        ) * sideMultiplier;

    float yRotation =
        (
            particlePos.z < playerRelativeZValue
            ? 0.5
            : -0.5
        ) * sideMultiplier;

    float zRotation = 0.75;

    vec2 cornerPosition = vec2(
        corner == 1 || corner == 2 ? 1.0 : -1.0,
        corner >= 2 ? 1.0 : -1.0
    );

    float size =
        SizeEnd < 0.0
        ? Params.x
        : mix(Params.x, SizeEnd, progress);

    vec3 localPosition = vec3(
        cornerPosition.x * size,
        cornerPosition.y * size * Aspect,
        0.0
    );

    localPosition =
        rotateZ(localPosition, zRotation);

    localPosition =
        rotateY(localPosition, yRotation);

    localPosition =
        rotateX(localPosition, xRotation);

    vec3 renderPosition =
        particlePos + localPosition;

    /*
     * Стандартная обработка спрайтов.
     */
    float frame =
        RandomSprite == 1
        ? floor(hash(seed, 4.0) * float(Frames))
        : min(
            floor(progress * float(Frames)),
            float(Frames - 1)
        );

    float u =
        corner == 1 || corner == 2
        ? 1.0
        : 0.0;

    float v =
        corner >= 2
        ? 0.0
        : 1.0;

    texCoord0 = vec2(
        u,
        (frame + v) / float(Frames)
    );

    /*
     * Стандартный GPU fade из JSON.
     */
    float fade = 1.0;

    if (Fade.x > 0.0) {
        fade *= smoothstep(
            0.0,
            Fade.x,
            progress
        );
    }

    if (Fade.y > 0.0) {
        fade *= 1.0 -
            smoothstep(
                1.0 - Fade.y,
                1.0,
                progress
            );
    }

    vec4 lightColor =
        texelFetch(Sampler2, UV2 / 16, 0);

    vertexColor =
        Color *
        lightColor *
        vec4(1.0, 1.0, 1.0, fade);

    sphericalVertexDistance =
        fog_spherical_distance(renderPosition);

    cylindricalVertexDistance =
        fog_cylindrical_distance(renderPosition);

    gl_Position =
        ProjMat *
        ModelViewMat *
        vec4(renderPosition, 1.0);
}