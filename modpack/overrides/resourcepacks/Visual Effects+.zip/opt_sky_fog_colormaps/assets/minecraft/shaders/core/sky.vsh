#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec3 skyDirection;


// ---------- LOWER HORIZON EXTENSION ----------

const float SKY_EXTENSION_START = 128.0;
const float SKY_EXTENSION_END = 320.0;
const float SKY_EXTENSION_DEPTH = 0.90;


// ---------- REMOVE BOBBING TRANSLATION ONLY ----------

mat4 getSkyProjection() {
    vec3 rowZ = vec3(
        ProjMat[0][2],
        ProjMat[1][2],
        ProjMat[2][2]
    );

    vec3 rowW = vec3(
        ProjMat[0][3],
        ProjMat[1][3],
        ProjMat[2][3]
    );

    // Восстанавливаем коэффициент глубины без смещения.
    float depthA = -dot(rowZ, rowW) /
        max(dot(rowW, rowW), 0.00000001);

    float depthB =
        ProjMat[3][2] + depthA * ProjMat[3][3];

    // Сохраняем FOV и вращение от view bobbing.
    mat4 skyProjection = ProjMat;

    // Убираем только перенос, внесённый перед проекцией.
    // Исходный коэффициент глубины сохраняется.
    skyProjection[3] = vec4(
        0.0,
        0.0,
        depthB,
        0.0
    );

    return skyProjection;
}


// ---------- MAIN ----------

void main() {
    float radialDistance = length(Position.xz);

    float extensionMask = smoothstep(
        SKY_EXTENSION_START,
        SKY_EXTENSION_END,
        radialDistance
    );

    vec3 extendedPosition = Position;

    extendedPosition.y = mix(
        Position.y,
        -radialDistance * SKY_EXTENSION_DEPTH,
        extensionMask
    );

    gl_Position =
        getSkyProjection() *
        ModelViewMat *
        vec4(extendedPosition, 1.0);

    sphericalVertexDistance =
        fog_spherical_distance(extendedPosition);

    cylindricalVertexDistance =
        fog_cylindrical_distance(extendedPosition);

    skyDirection = extendedPosition;
}