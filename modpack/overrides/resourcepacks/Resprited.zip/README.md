## Resprited

A Minecraft resource pack
created by **Infernalizard**


Same old minecraft, but resprited

This mod-independent Resource Pack presents my own take on minecraft's visual aspects while preserving their core feeling we all know and love.

---
<br>

## License
**© 2024 Infernalizard. All Rights Reserved.**

The user **may not** copy, modify, redistribute and/or use any part of this project without **explicit permission** from the author.

All unofficial iterations of this project must remain **personal** and not be distributed and public showcases of this pack must contain proper credits.

**None** of the assets related to this project are to be used in any kind of **AI related activity** (training and such).

---
<br>

## How to install
1. Download your preferred version from the [Modrinth page](https://modrinth.com/project/Q9KwAZ06).
2. Place the `.zip` file you just downloaded into your `resourcepacks/` folder.
3. Launch Minecraft and enable it in your resource packs menu.

---
<br>

## How to contact me
- Discord Username: @infernalizard
- Official Resprited [Discord Server](https://discord.gg/hjZv2N3CQf)